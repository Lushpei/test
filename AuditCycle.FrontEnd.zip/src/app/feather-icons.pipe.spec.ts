import { FeatherIconsPipe } from './feather-icons.pipe';

describe('FeatherIconsPipe', () => {
  it('create an instance', () => {
    const pipe = new FeatherIconsPipe();
    expect(pipe).toBeTruthy();
  });
});
