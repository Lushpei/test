import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-facility-details',
  templateUrl: './facility-details.component.html',
  styleUrls: ['./facility-details.component.css']
})
export class FacilityDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
