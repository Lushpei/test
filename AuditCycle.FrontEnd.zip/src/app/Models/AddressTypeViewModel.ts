export class AddressTypeViewModel{
    id: number;
    title: string;    
  }