export interface AdminMenuModule {
    title: string;
    hrefLink: string;
  }
  