import { Component, OnInit } from '@angular/core';
import {AdminMenuModule} from './models/adminMenuModels';
import {Observable} from 'rxjs';

@Component({
  selector: 'app-admin-management',
  templateUrl: './admin-management.component.html',
  styleUrls: ['./admin-management.component.css']
})
export class AdminManagementComponent implements OnInit {

  
  constructor() { }

  ngOnInit() {
   
  }

}
