
/**================================== NOTE ===============================================
 * This section to be modify at actual implementation. Thais is just an example!!
 * --------------------------------------------------------------------------------------**/

export class AccountTest {
  id: string;
  accountNumber: string;
  name: string;
  statusId: number;
  address: string;
  phone: string;
}
