import {Component, OnInit} from '@angular/core';
import {AccountTest} from '../Models/AccountModels';
import {AccountManagementService} from '../account-management.service';

@Component({
  selector: 'app-acc-create',
  templateUrl: './acc-create.component.html',
  styleUrls: ['./acc-create.component.css']
})
export class AccCreateComponent implements OnInit {

  newAccount: AccountTest;

  isActiveFieldName: string;
  isActiveFieldNumber: string;
  isActiveFieldAddressType: string;
  isActiveSelector: string;
  isActiveFieldPhone: string;
  isActiveFieldAddress: string;

  step: number;
  statusName: string;
  statusIds: any[] = [
    {id: 1, name: 'option 1'},
    {id: 2, name: 'option 2'},
    {id: 3, name: 'option 3'},
    {id: 4, name: 'option 4'},
    {id: 5, name: 'option 5'}
  ];


  constructor(private accService: AccountManagementService) {
    this.newAccount = new AccountTest();
    this.newAccount.name = '';
    this.newAccount.address = '';
    this.newAccount.phone = '';
    this.newAccount.accountNumber = '';
    this.step = 1;
    this.statusName = '';
    this.isActiveSelector = '';
  }


  changeStateFieldName(flag: string): void {
    console.log('this.isActiveFieldName');
    if (this.newAccount.name !== '' && !!flag) {
      this.isActiveFieldName = flag;
    } else if (this.newAccount.name === '') {
      this.isActiveFieldName = flag;
    }
  }

  changeStateFieldNumber(flag: string): void {
    if (this.newAccount.accountNumber !== '' && !!flag) {
      this.isActiveFieldNumber = flag;
    } else if (this.newAccount.accountNumber === '') {
      this.isActiveFieldNumber = flag;
    }
  }

  changeStateFieldAddress(flag: string): void {
    if (this.newAccount.address !== '' && !!flag) {
      this.isActiveFieldAddress = flag;
    } else if (this.newAccount.address === '') {
      this.isActiveFieldAddress = flag;
    }
  }

  changeStateFieldPhone(flag: string): void {
    if (this.newAccount.phone !== '' && !!flag) {
      this.isActiveFieldPhone = flag;
    } else if (this.newAccount.phone === '') {
      this.isActiveFieldPhone = flag;
    }
  }

  setStatusId(id: number) {
   this.newAccount.statusId = this.statusIds[id].id;
    this.statusName = this.statusIds[id].name;
  }

  changeStateFieldTypeAddr(flag: string): void {
    this.isActiveSelector = flag === 'active' ? 'active' : '';
    if (this.newAccount.statusId && !!flag) {
      this.isActiveFieldAddressType = flag;
    } else if (!this.newAccount.statusId) {
      this.isActiveFieldAddressType = flag;
    }
  }

  setStep(step: number) {
    this.step = step;
  }

  ngOnInit() {
  }

  setNewStatus(id: any): void {
    this.newAccount.statusId = id;
  }

  saveAccount() {
console.log('saved');
  }
}
