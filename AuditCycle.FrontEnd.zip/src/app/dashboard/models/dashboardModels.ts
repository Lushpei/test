export interface TileModule {
  title: string;
  iconName: string;
  hrefLink: string;
}
