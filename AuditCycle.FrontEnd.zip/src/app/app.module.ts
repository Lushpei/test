import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule} from '@angular/common/http';
import { NgbModule} from '@ng-bootstrap/ng-bootstrap';


import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';

import { AccountManagementService } from './account-management/account-management.service';

import { AccountManagementComponent } from './account-management/account-management.component';
import { AccCreateComponent } from './account-management/acc-create/acc-create.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { FeatherIconsPipe } from './feather-icons.pipe';
import { AccReadComponent } from './account-management/acc-read/acc-read.component';
import { AccUpdateComponent } from './account-management/acc-update/acc-update.component';
import { AccDeleteComponent } from './account-management/acc-delete/acc-delete.component';
import { LoginComponent } from './auth-management/login/login.component';
import { DashboardModuleComponent } from './dashboard/dashboard-module/dashboard-module.component';
import { DashboardService } from './dashboard/dashboard.service';
import { ContactsService } from './contacts/contacts.service';
import { FacilityService } from './facility/facility.service';
import { AddressComponent } from './address/address.component';
import { AddressReadComponent } from './address/address-read/address-read.component';
import { AddressCreateComponent } from './address/address-create/address-create.component';
import { AddressService } from './address/address.service';
import { AccDetailComponent } from './account-management/acc-detail/acc-detail.component';
import { AuthService } from './auth-management/auth.service';

import { FacilityListComponent } from './facility/facility-list/facility-list.component';
import { FacilitySearchComponent } from './facility/facility-search/facility-search.component';
import { FacilityResultComponent } from './facility/facility-result/facility-result.component';
import { FacilityDetailsComponent } from './facility/facility-details/facility-details.component';
import { AdminManagementComponent } from './admin-management/admin-management.component';

import { UserMenuComponent } from './user-menu/menu.component';
import { AdminMenuComponent } from './admin-management/admin-menu/admin-menu.component';
import { AdminMenuService } from './admin-management/admin-management.service';

@NgModule({
  declarations: [
    AppComponent,
    AccountManagementComponent,
    AccCreateComponent,
    DashboardComponent,
    FeatherIconsPipe,
    AccReadComponent,
    AccUpdateComponent,
    AccDeleteComponent,
    LoginComponent,
    DashboardModuleComponent,
    AddressComponent,
    AddressReadComponent,
    AddressCreateComponent,
    AccDetailComponent,
    FacilityListComponent,
    FacilitySearchComponent,
    FacilityResultComponent,
    FacilityDetailsComponent,
    AdminManagementComponent,
    UserMenuComponent,
    AdminMenuComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    NgbModule.forRoot(),
    BrowserModule,
    ReactiveFormsModule
  ],
  providers: [
    AccountManagementService,
    DashboardService,
    FacilityService,
    ContactsService,
    AddressService,
    AuthService,
    AdminMenuService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
