import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {UserMenuComponent} from './menu.component';

